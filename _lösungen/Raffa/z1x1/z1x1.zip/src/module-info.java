module AXB_Medal_Distr {
}//module